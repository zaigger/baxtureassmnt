import { Controller, Get, Post, Put, Delete, Param, Body } from '@nestjs/common';
import { UserService } from './user.service';
import { User } from './user.module';
import { CreateUserDto } from './dto/create-user.dto';

@Controller('users')
export class UserController {
  constructor(private userService: UserService) {}

  @Get('/allusers')
  async findAll(): Promise<User[]> {
    return await this.userService.findAll();
  }

  @Get('/getbyid')
  async findOne(@Param('id') id: string): Promise<User> {
    return await this.userService.findOne(id);
  }

  @Post('/newuser')
  async create(@Body() user: CreateUserDto): Promise<any> {
    return await this.userService.create(user);
  }

  @Put('/update')
  async update(@Param('id') id: string, @Body() user: CreateUserDto): Promise<User> {
    return await this.userService.update(id, user);
  }

  @Delete('/delete')
  async delete(@Param('id') id: string): Promise<User> {
    return await this.userService.delete(id);
  }
}